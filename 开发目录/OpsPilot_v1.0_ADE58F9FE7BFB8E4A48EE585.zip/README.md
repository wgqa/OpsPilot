# OpsPilot — Agent 工程项目

**状态：** DESIGN APPROVED · IMPLEMENTATION IN PROGRESS ONLY AFTER LUNA STARTS D1（尚无测试通过声明）  
**唯一设计与验收基线：** [`docs/baseline/v1.0-implementation-baseline.md`](docs/baseline/v1.0-implementation-baseline.md)  
**Luna 第一阶段任务：** [`docs/handoff/Luna-D1-implementation-brief.md`](docs/handoff/Luna-D1-implementation-brief.md)  
**开发进度：** [`TASKS.md`](TASKS.md)；**工程规则：** [`AGENTS.md`](AGENTS.md)

## 目标

为负责客户 API 接入故障的技术支持/后端工程师构建一个由 LangChain + LangGraph 组织的 Agent：用 MCP/Function Calling 调查 401，基于来源充分的证据准备计划，经过可信人工批准，以持久 Action Intent + Domain SQLite 事务实现幂等修复，经同一调用方主体及业务端点验证，再生成并幂等交付工单报告。后续 P0 包括一种经审核长期记忆、一个按需加载的排障 Skill 和 E01–E10 控制回归。

首周仅 S1：客户端凭证引用过旧造成 401；迷惑负例是主体已停用，不能通过修改凭证绕过。**不是泛化 AIOps、Coding Agent 或工单问答 Demo。**

## 代码状态与启动方式

当前交付的是设计/任务文档包，**不含完成的业务代码、可用运行环境或假造的测试日志**。具体 Python、依赖版本、环境和启动命令在 D1 由 Luna 实测记录并填入 README；之前不得虚构 `pip install`、`pytest` 或运行成功截图。建议 Python 3.11+、LangGraph、LangChain、MCP Python SDK、pytest 和 SQLite，但版本必须 D1 冻结。

### D1 需要产出的启动合同

- 单命令重置 S1 POS / DISABLED fixture；
- 单命令启动 Demo API；
- 单命令发起**同一调用方身份**的业务探测；
- 单命令运行 `smoke_tool_call`、`smoke_mcp`、`smoke_checkpoint_interrupt`；
- 单命令运行 D1 单测/集成测试。

实际命令和环境变量范例由 Luna 在提交 D1 代码时填写，不能把此清单等同已实现能力。

## 合格与不合格的证据

可称完成“真实恢复”需要原业务端点 401→200、同一 principal/integration/route 的请求/响应与业务断言；仅数据库字段或 `/health` 变化不算。审批/重试可靠性需要持久 Intent、Domain Ledger、原子修改和 E05/E08/E09 注入测试证据。设计放行不等于代码验收。

## 文档层级

1. 唯一有效规范：`docs/baseline/v1.0-implementation-baseline.md`。
2. 本轮实施任务：`docs/handoff/Luna-D1-implementation-brief.md`、`TASKS.md`。
3. 工程边界：`AGENTS.md`。
4. 评审历史：`docs/reviews/R1.md` ... `R5.md` 及 `v0.3-approved-source.md`，仅用于溯源，**不作为并行的开发需求**。

> 本 README 是**已冻结文档的可合并同步稿**。若现有本地仓库已有 README，请按迁移清单合并而不是不经检查覆盖原文件。
